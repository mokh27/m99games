<?php include  TEMPLATE_PATH . "/includes/header.php" ?>
<div class="container">
	<div class="game-container text-center">
		<img src="<?php echo DOMAIN . TEMPLATE_PATH . "/images/404.png" ?>">
	</div>
</div>
<?php include  TEMPLATE_PATH . "/includes/footer.php" ?>