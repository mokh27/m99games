<h4 class="text-uppercase mb-4">Footer 3</h4>
<p class="lead mb-0">
	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
</p>